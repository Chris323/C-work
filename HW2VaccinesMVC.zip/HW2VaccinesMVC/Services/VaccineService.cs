﻿using HW2VaccinesMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HW2VaccinesMVC.Services
{
    public interface IVaccineService 
    {
        List<Vaccine> GetVaccines();
        Vaccine GetVaccine(int id);
        void UpdateDoses(int id, int newDoses);
        void AddVaccine(Vaccine vaccine);
        void EditVaccine(int id, string name, int dosesRequired, int? daysBetweenDoses);
    }

    public class VaccineService : IVaccineService
    {
        private readonly AppDbContext _db;

        public VaccineService(AppDbContext db)
        {
            _db = db;
        }
        public List<Vaccine> GetVaccines()
        {
            try
            {
                return _db.Vaccines.ToList();
            }
            catch (Exception ex)
            {
                return new List<Vaccine>();
            }
            
        }

        // Get a single vaccine
        public Vaccine GetVaccine(int id)
        {
            return _db.Vaccines.Where(v => v.Id == id).SingleOrDefault();
        }

        //update only the doses
        public void UpdateDoses(int id, int newDoses)
        {
            var current = _db.Vaccines.Where(v => v.Id == id).SingleOrDefault();
            var newDoseAmount = current.TotalDosesRecieved + newDoses;
            //Will need to fix line beneath
            var remainingDoses = current.TotalDosesLeft + newDoses;
            current.TotalDosesRecieved = newDoseAmount;
            current.TotalDosesLeft = remainingDoses;
            _db.SaveChanges();
        }


        //New Vaccine (add a new one) the program binds the view with the controller and service (assumption)
        public void AddVaccine(Vaccine vaccine)
        {
            _db.Vaccines.Add(vaccine);
            _db.SaveChanges();
        }

        public void EditVaccine(int id, string name, int dosesRequired, int? daysBetweenDoses)
        {
            var vaccine = _db.Vaccines.Where(v => v.Id == id).SingleOrDefault();
            vaccine.Name = name;
            vaccine.DosesRequired = dosesRequired;
            vaccine.DaysBetweenDoses = daysBetweenDoses;
            _db.SaveChanges();
        }
    }
}
