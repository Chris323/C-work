﻿using System;

namespace Lab1pt2
{
    class SortedListCheck
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter List: ");

        }
    }
}
