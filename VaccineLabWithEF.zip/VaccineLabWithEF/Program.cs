﻿using System;

namespace VaccineLabWithEF
{
    class Program
    {
        static void Main(string[] args)
        {
            //Using remove messes with Id column
/*            using var db = new AppDBContext();
            var deleteVac = db.Vaccines.Find(3);
            db.Vaccines.Remove(deleteVac);
            db.SaveChanges();*/

            var driver = new ViewController();
            driver.VaccineListDisplay();
        }
    }
}