﻿using System;

namespace NewTryForLearning
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello there!");
        }
    }
}
